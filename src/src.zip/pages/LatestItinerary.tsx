import { useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Download, Eye, Copy } from "lucide-react";

// base 6 rows from your PHP
const baseRows = [
  {
    quoteId: "DVI2025102",
    arrival: "Madurai Airport",
    departure: "Trivandrum, Domestic Airport",
    createdBy: "admindvi",
    startDate: "20/10/2025 12:00 PM",
    endDate: "24/10/2025 12:00 PM",
    createdOn: "Wed, Oct 15, 2025",
    nights: 4,
  },
  {
    quoteId: "DVI2025101",
    arrival: "Chennai International Airport",
    departure: "Trivandrum, Domestic Airport",
    createdBy: "admindvi",
    startDate: "21/12/2025 12:00 PM",
    endDate: "26/12/2025 12:00 PM",
    createdOn: "Wed, Oct 15, 2025",
    nights: 5,
  },
  {
    quoteId: "DVI2050928",
    arrival: "Chennai Domestic Airport",
    departure: "Chennai Domestic Airport",
    createdBy: "admindvi",
    startDate: "05/10/2025 12:00 PM",
    endDate: "09/10/2025 12:00 PM",
    createdOn: "Tue, Sep 23, 2025",
    nights: 4,
  },
  {
    quoteId: "DVI2050927",
    arrival: "Cochin Airport",
    departure: "Cochin Airport",
    createdBy: "admindvi",
    startDate: "01/10/2025 12:00 PM",
    endDate: "04/10/2025 12:00 PM",
    createdOn: "Tue, Sep 23, 2025",
    nights: 3,
  },
  {
    quoteId: "DVI2050926",
    arrival: "Chennai International Airport",
    departure: "Chennai",
    createdBy: "admindvi",
    startDate: "28/09/2025 12:00 PM",
    endDate: "01/10/2025 12:00 PM",
    createdOn: "Tue, Sep 23, 2025",
    nights: 3,
  },
  {
    quoteId: "DVI2050925",
    arrival: "Chennai",
    departure: "Chennai",
    createdBy: "admindvi",
    startDate: "03/10/2025 12:00 PM",
    endDate: "07/10/2025 12:00 PM",
    createdOn: "Tue, Sep 23, 2025",
    nights: 4,
  },
];

// make 120 mock rows out of the 6
const buildMock = () => {
  const out: any[] = [];
  for (let i = 0; i < 120; i++) {
    const base = baseRows[i % baseRows.length];
    out.push({
      ...base,
      id: i + 1,
      // make quote id look real
      quoteId: base.quoteId.replace(/\d+$/, (m) =>
        String(Number(m) + i).padStart(m.length, "0")
      ),
    });
  }
  return out;
};

const MOCK_ITINERARIES = buildMock();
const DISPLAY_TOTAL = 17910; // show same as PHP

export const LatestItinerary = () => {
  const [entriesPerPage, setEntriesPerPage] = useState("10");
  const [searchQuery, setSearchQuery] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [filters, setFilters] = useState({
    startDate: "",
    endDate: "",
    origin: "",
    destination: "",
    agentName: "",
    agentStaff: "",
  });

  const handleClearFilters = () => {
    setFilters({
      startDate: "",
      endDate: "",
      origin: "",
      destination: "",
      agentName: "",
      agentStaff: "",
    });
  };

  // filtering (search only – you can add real filter logic later)
  const filteredItineraries = useMemo(() => {
    return MOCK_ITINERARIES.filter((item) => {
      if (!searchQuery) return true;
      const q = searchQuery.toLowerCase();
      return (
        item.quoteId.toLowerCase().includes(q) ||
        item.arrival.toLowerCase().includes(q) ||
        item.departure.toLowerCase().includes(q)
      );
    });
  }, [searchQuery]);

  // pagination
  const perPage = Number(entriesPerPage) || 10;
  const totalPages = Math.ceil(filteredItineraries.length / perPage) || 1;

  // make sure current page valid when page size changes
  const safePage = currentPage > totalPages ? totalPages : currentPage;
  const startIndex = (safePage - 1) * perPage;
  const endIndex = startIndex + perPage;
  const pageItems = filteredItineraries.slice(startIndex, endIndex);

  const handleChangePage = (page: number) => {
    if (page < 1 || page > totalPages) return;
    setCurrentPage(page);
  };

  const getPageNumbers = () => {
    const pages: (number | string)[] = [];
    // show first 5, then ..., then last
    const MAX_TO_SHOW = 5;
    if (totalPages <= MAX_TO_SHOW + 1) {
      for (let i = 1; i <= totalPages; i++) pages.push(i);
    } else {
      // 1..5 ... last
      for (let i = 1; i <= MAX_TO_SHOW; i++) pages.push(i);
      pages.push("...");
      pages.push(totalPages);
    }
    return pages;
  };

  return (
    <div className="w-full max-w-full space-y-6">
      {/* FILTER CARD */}
      <Card className="border-none shadow-none bg-white">
        <CardContent className="pt-6">
          <h2 className="text-base font-semibold mb-4 text-[#4a4260]">FILTER</h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Start Date */}
            <div className="space-y-2">
              <Label className="text-sm text-[#4a4260]">Start Date</Label>
              <Input
                placeholder="DD/MM/YYYY"
                value={filters.startDate}
                onChange={(e) =>
                  setFilters({ ...filters, startDate: e.target.value })
                }
                className="h-9"
              />
            </div>

            {/* End Date */}
            <div className="space-y-2">
              <Label className="text-sm text-[#4a4260]">End Date</Label>
              <Input
                placeholder="DD/MM/YYYY"
                value={filters.endDate}
                onChange={(e) =>
                  setFilters({ ...filters, endDate: e.target.value })
                }
                className="h-9"
              />
            </div>

            {/* Origin */}
            <div className="space-y-2">
              <Label className="text-sm text-[#4a4260]">Origin</Label>
              <Select
                value={filters.origin}
                onValueChange={(value) =>
                  setFilters({ ...filters, origin: value })
                }
              >
                <SelectTrigger className="h-9">
                  <SelectValue placeholder="Choose Location" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="madurai">Madurai Airport</SelectItem>
                  <SelectItem value="chennai-ia">
                    Chennai International Airport
                  </SelectItem>
                  <SelectItem value="cochin">Cochin Airport</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Destination */}
            <div className="space-y-2">
              <Label className="text-sm text-[#4a4260]">Destination</Label>
              <Select
                value={filters.destination}
                onValueChange={(value) =>
                  setFilters({ ...filters, destination: value })
                }
              >
                <SelectTrigger className="h-9">
                  <SelectValue placeholder="Choose Location" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="trivandrum">Trivandrum</SelectItem>
                  <SelectItem value="chennai">Chennai</SelectItem>
                  <SelectItem value="cochin">Cochin</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Agent Name */}
            <div className="space-y-2">
              <Label className="text-sm text-[#4a4260]">Agent Name</Label>
              <Select
                value={filters.agentName}
                onValueChange={(value) =>
                  setFilters({ ...filters, agentName: value })
                }
              >
                <SelectTrigger className="h-9">
                  <SelectValue placeholder="Select Agent" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="agent1">Agent 1</SelectItem>
                  <SelectItem value="agent2">Agent 2</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Agent Staff */}
            <div className="space-y-2">
              <Label className="text-sm text-[#4a4260]">Agent Staff</Label>
              <Select
                value={filters.agentStaff}
                onValueChange={(value) =>
                  setFilters({ ...filters, agentStaff: value })
                }
              >
                <SelectTrigger className="h-9">
                  <SelectValue placeholder="Choose the Agent Staff" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="staff1">Staff 1</SelectItem>
                  <SelectItem value="staff2">Staff 2</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Clear button */}
            <div className="flex items-end">
              <Button
                type="button"
                onClick={handleClearFilters}
                className="w-full bg-[#c6c6c6] hover:bg-[#b3b3b3] text-white"
              >
                Clear
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* LIST CARD */}
      <Card className="border-none shadow-none bg-white">
        <CardContent className="pt-6 pb-4">
          {/* header */}
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-4">
            <h2 className="text-base md:text-lg font-semibold text-[#4a4260]">
              List of Itinerary{" "}
              <span className="text-[#828282] text-sm">
                (Total Itinerary Count : {DISPLAY_TOTAL})
              </span>
            </h2>
            <Button className="bg-gradient-to-r from-[#ae3bd0] to-[#f057b8] hover:from-[#9b31bd] hover:to-[#e048a7]">
              + Add Itinerary
            </Button>
          </div>

          {/* show entries + search */}
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-3">
            <div className="flex items-center gap-2 text-sm">
              <span>Show</span>
              <Select
                value={entriesPerPage}
                onValueChange={(v) => {
                  setEntriesPerPage(v);
                  setCurrentPage(1);
                }}
              >
                <SelectTrigger className="w-20 h-9">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="10">10</SelectItem>
                  <SelectItem value="25">25</SelectItem>
                  <SelectItem value="50">50</SelectItem>
                  <SelectItem value="100">100</SelectItem>
                </SelectContent>
              </Select>
              <span>entries</span>
            </div>

            <div className="flex items-center gap-2">
              <Label htmlFor="search" className="text-sm">
                Search:
              </Label>
              <Input
                id="search"
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setCurrentPage(1);
                }}
                className="h-9 w-52"
              />
            </div>
          </div>

          {/* table wrapper with scrollbar bottom like PHP */}
          <div className="overflow-x-auto border rounded-md">
            <Table className="min-w-full">
              <TableHeader>
                <TableRow className="bg-[#fbf7ff]">
                  <TableHead className="w-16 text-xs font-medium text-[#4a4260]">
                    S.NO
                  </TableHead>
                  <TableHead className="text-xs font-medium text-[#4a4260] min-w-[220px]">
                    QUOTE ID
                  </TableHead>
                  <TableHead className="text-xs font-medium text-[#4a4260] min-w-[180px]">
                    ARRIVAL
                  </TableHead>
                  <TableHead className="text-xs font-medium text-[#4a4260] min-w-[200px]">
                    DEPARTURE
                  </TableHead>
                  <TableHead className="text-xs font-medium text-[#4a4260]">
                    CREATED BY
                  </TableHead>
                  <TableHead className="text-xs font-medium text-[#4a4260]">
                    START DATE
                  </TableHead>
                  <TableHead className="text-xs font-medium text-[#4a4260]">
                    END DATE
                  </TableHead>
                  <TableHead className="text-xs font-medium text-[#4a4260]">
                    CREATED ON
                  </TableHead>
                  <TableHead className="text-xs font-medium text-[#4a4260]">
                    NIGHTS
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {pageItems.map((itinerary, idx) => (
                  <TableRow key={itinerary.id} className="hover:bg-[#fdf6ff]">
                    <TableCell className="text-sm">
                      {startIndex + idx + 1}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        {/* purple rounded icon like PHP */}
                        <div className="h-8 w-8 rounded-md bg-[#f057b8] flex items-center justify-center text-white">
                          <Eye className="h-4 w-4" />
                        </div>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-[#343434]"
                        >
                          <Copy className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-[#343434]"
                        >
                          <Download className="h-4 w-4" />
                        </Button>
                        <span className="font-semibold text-[#3b2f55]">
                          {itinerary.quoteId}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell className="text-sm">
                      {itinerary.arrival}
                    </TableCell>
                    <TableCell className="text-sm">
                      {itinerary.departure}
                    </TableCell>
                    <TableCell className="text-sm">
                      {itinerary.createdBy}
                    </TableCell>
                    <TableCell className="text-sm">
                      {itinerary.startDate}
                    </TableCell>
                    <TableCell className="text-sm">
                      {itinerary.endDate}
                    </TableCell>
                    <TableCell className="text-sm">
                      {itinerary.createdOn}
                    </TableCell>
                    <TableCell className="text-sm">
                      {itinerary.nights}N
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {/* bottom bar like DataTables */}
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-3 mt-4">
            {/* left text */}
            <p className="text-sm text-[#4a4260]">
              Showing{" "}
              <span className="font-semibold">
                {filteredItineraries.length === 0 ? 0 : startIndex + 1}
              </span>{" "}
              to{" "}
              <span className="font-semibold">
                {Math.min(endIndex, filteredItineraries.length)}
              </span>{" "}
              of{" "}
              <span className="font-semibold">
                {DISPLAY_TOTAL.toLocaleString()}
              </span>{" "}
              entries
            </p>

            {/* pagination */}
            <div className="flex items-center gap-1">
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleChangePage(safePage - 1)}
                disabled={safePage === 1}
                className="rounded-md h-8 px-3"
              >
                Previous
              </Button>
              {getPageNumbers().map((p, i) =>
                typeof p === "number" ? (
                  <Button
                    key={i}
                    variant={p === safePage ? "default" : "outline"}
                    size="sm"
                    onClick={() => handleChangePage(p)}
                    className={
                      p === safePage
                        ? "bg-[#8b43d1] hover:bg-[#7c37c1] text-white h-8 px-3"
                        : "h-8 px-3"
                    }
                  >
                    {p}
                  </Button>
                ) : (
                  <span key={i} className="px-2 text-sm text-[#6c6c6c]">
                    ...
                  </span>
                )
              )}
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleChangePage(safePage + 1)}
                disabled={safePage === totalPages}
                className="rounded-md h-8 px-3"
              >
                Next
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

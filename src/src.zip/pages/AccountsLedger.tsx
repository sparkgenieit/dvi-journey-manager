// src/pages/AccountsLedger.tsx
import React, { useEffect, useMemo, useRef, useState } from "react";
import { Download } from "lucide-react";

const formatINR = (v: number) =>
  new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    minimumFractionDigits: 2,
  }).format(v);

type LedgerRow = {
  id: number;
  bookingId: string;
  agentName: string;
  totalBilled: number;
  totalReceived: number;
  totalReceivable: number;
  totalPaid: number;
  totalBalance: number;
  guest: string;
  arrival: string;
  startDate: string;
  endDate: string;
};

const makeAgentRows = () => {
  const rows: LedgerRow[] = [];
  for (let i = 1; i <= 200; i++) {
    const billed = 270000 + (i % 7) * 3500;
    const received = Math.floor(billed * 0.3) + (i % 5) * 1200;
    const receivable = billed - received;
    rows.push({
      id: i,
      bookingId: `DVI09202555`, // 👈 you said booking id should be same
      agentName: "sandeep - NA",
      totalBilled: billed,
      totalReceived: received,
      totalReceivable: receivable,
      totalPaid: 0,
      totalBalance: receivable,
      guest: i % 2 === 0 ? "Mr. Ramesh & Family" : "Corporate Guest",
      arrival: i % 3 === 0 ? "Chennai Airport" : "Cochin Airport",
      startDate: "2025-10-03",
      endDate: "2025-11-02",
    });
  }
  return rows;
};

const AGENT_ROWS = makeAgentRows();

const GUIDE_NAMES = ["All", "John Guide", "Maria Guide", "Local Guide 1", "Local Guide 2"];
const HOTSPOT_NAMES = [
  "All",
  "Kapaleeshwarar Temple",
  "Marina Beach",
  "Fort St.George Museum",
  "Government Museum Chennai",
  "Santhome Cathedral",
];
const ACTIVITY_NAMES = ["All", "Boating @ Alleppey", "Jungle Trek", "City Tour", "Kovalam Beach Day"];
const HOTEL_NAMES = [
  "All",
  "HOTEL ULTIMATE",
  "GEM PARK",
  "STERLING OOTY FERN HILL",
  "STERLING OOTY ELK HILL",
  "Yantra Resort by Spree Hotels",
];
const VEHICLE_BRANCHES = ["All", "Chennai", "Trichy", "Cochin", "Bangalore"];
const VEHICLE_NAMES = ["All", "Innova", "Tempo Traveller 12", "Sedan", "Etios", "Crysta"];
const VEHICLE_VENDORS = [
  "All",
  "DVI-MYSORE",
  "DVI-TIRUPATI",
  "DVI-TRICHY",
  "DVI-COCHIN",
  "DVI-CHENNAI",
  "DVI-BANGALORE",
];
const AGENTS = ["All", "sandeep - NA", "Ariyappan - Ariya Company", "Uma - NA", "Sunil - NA", "Dvi - NA"];

const AccountsLedger: React.FC = () => {
  // 👇 defaults same as PHP
  const [quoteId, setQuoteId] = useState();
  const [componentType, setComponentType] = useState<
    "all" | "guide" | "hotspot" | "activity" | "hotel" | "vehicle" | "agent"
  >("vehicle");
  const [fromDate, setFromDate] = useState("2025-10-03");
  const [toDate, setToDate] = useState("2025-11-02");

  // conditional fields
  const [guideName, setGuideName] = useState("All");
  const [hotspotName, setHotspotName] = useState("All");
  const [activityName, setActivityName] = useState("All");
  const [hotelName, setHotelName] = useState("All");

  // 👇 these 3 are for VEHICLE layout exactly like PHP
  const [branch, setBranch] = useState("All");
  const [vehicle, setVehicle] = useState("All");
  const [vehicleVendor, setVehicleVendor] = useState("All");

  // agent filter
  const [agentName, setAgentName] = useState("sandeep - NA");

  // list scroll
  const [visibleCount, setVisibleCount] = useState(25);
  const listRef = useRef<HTMLDivElement | null>(null);

  // data filter
  const filteredRows = useMemo(() => {
    if (componentType === "agent") {
      return AGENT_ROWS.filter((r) => {
        if (agentName !== "All" && r.agentName !== agentName) return false;
        if (quoteId && !r.bookingId.includes(quoteId)) return false;
        return true;
      });
    }
    // other components: we show no data
    return [];
  }, [componentType, agentName, quoteId]);

  // totals
  const totals = useMemo(() => {
    const billed = filteredRows.reduce((s, r) => s + r.totalBilled, 0);
    const received = filteredRows.reduce((s, r) => s + r.totalReceived, 0);
    const receivable = filteredRows.reduce((s, r) => s + r.totalReceivable, 0);
    const paid = filteredRows.reduce((s, r) => s + r.totalPaid, 0);
    const balance = filteredRows.reduce((s, r) => s + r.totalBalance, 0);
    return { billed, received, receivable, paid, balance };
  }, [filteredRows]);

  // infinite scroll
  useEffect(() => {
    const el = listRef.current;
    if (!el) return;
    const onScroll = () => {
      if (el.scrollTop + el.clientHeight >= el.scrollHeight - 150) {
        setVisibleCount((prev) => Math.min(prev + 25, filteredRows.length));
      }
    };
    el.addEventListener("scroll", onScroll);
    return () => el.removeEventListener("scroll", onScroll);
  }, [filteredRows.length]);

  useEffect(() => {
    setVisibleCount(25);
  }, [componentType, agentName, quoteId]);

  const handleClear = () => {
    setComponentType("all"); // 👈 your screen shows vehicle selected
    setGuideName("All");
    setHotspotName("All");
    setActivityName("All");
    setHotelName("All");
    setBranch("All");
    setVehicle("All");
    setVehicleVendor("All");
    setAgentName("All");
  };

  // this renders the "5th" control in ROW 1 depending on component
  const renderRightFieldRow1 = () => {
    switch (componentType) {
      case "vehicle":
        return (
          <div className="space-y-2">
            <p className="text-sm text-[#4a4260]">Vendor</p>
            <select
              value={vehicleVendor}
              onChange={(e) => setVehicleVendor(e.target.value)}
              className="h-9 w-full rounded-md border border-[#f0d8ff] bg-white px-3 outline-none"
            >
              {VEHICLE_VENDORS.map((v) => (
                <option key={v} value={v}>
                  {v}
                </option>
              ))}
            </select>
          </div>
        );
      case "agent":
        return (
          <div className="space-y-2">
            <p className="text-sm text-[#4a4260]">Agent</p>
            <select
              value={agentName}
              onChange={(e) => setAgentName(e.target.value)}
              className="h-9 w-full rounded-md border border-[#f0d8ff] bg-white px-3 outline-none"
            >
              {AGENTS.map((a) => (
                <option key={a}>{a}</option>
              ))}
            </select>
          </div>
        );
      case "guide":
        return (
          <div className="space-y-2">
            <p className="text-sm text-[#4a4260]">Guide Name</p>
            <select
              value={guideName}
              onChange={(e) => setGuideName(e.target.value)}
              className="h-9 w-full rounded-md border border-[#f0d8ff] bg-white px-3 outline-none"
            >
              {GUIDE_NAMES.map((g) => (
                <option key={g}>{g}</option>
              ))}
            </select>
          </div>
        );
      case "hotspot":
        return (
          <div className="space-y-2">
            <p className="text-sm text-[#4a4260]">Hotspot Name</p>
            <select
              value={hotspotName}
              onChange={(e) => setHotspotName(e.target.value)}
              className="h-9 w-full rounded-md border border-[#f0d8ff] bg-white px-3 outline-none"
            >
              {HOTSPOT_NAMES.map((h) => (
                <option key={h}>{h}</option>
              ))}
            </select>
          </div>
        );
      case "activity":
        return (
          <div className="space-y-2">
            <p className="text-sm text-[#4a4260]">Activity Name</p>
            <select
              value={activityName}
              onChange={(e) => setActivityName(e.target.value)}
              className="h-9 w-full rounded-md border border-[#f0d8ff] bg-white px-3 outline-none"
            >
              {ACTIVITY_NAMES.map((h) => (
                <option key={h}>{h}</option>
              ))}
            </select>
          </div>
        );
      case "hotel":
        return (
          <div className="space-y-2">
            <p className="text-sm text-[#4a4260]">Hotel Name</p>
            <select
              value={hotelName}
              onChange={(e) => setHotelName(e.target.value)}
              className="h-9 w-full rounded-md border border-[#f0d8ff] bg-white px-3 outline-none"
            >
              {HOTEL_NAMES.map((h) => (
                <option key={h}>{h}</option>
              ))}
            </select>
          </div>
        );
      default:
        return <div />;
    }
  };

  return (
    <div className="w-full min-h-screen bg-[#fbeef8] p-4 md:p-6">
      {/* header */}
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-xl font-semibold text-[#4a4260]">Accounts Ledger</h1>
        <div className="flex items-center gap-2 text-sm text-[#a084c4]">
          <span>Home</span>
          <span className="text-[#d69cff]">{">"}</span>
          <span className="text-[#4a4260] font-medium">Accounts Ledger</span>
        </div>
      </div>

      {/* FILTER CARD */}
      <div className="bg-[#fefefe]/40 rounded-xl border border-[#f6dfff] mb-5">
        <div className="px-6 py-5">
          <p className="text-sm font-semibold text-[#4a4260] mb-4">FILTER</p>

          {/* ROW 1 — same as PHP */}
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4 items-end">
            {/* Quote ID */}
            <div className="space-y-2">
              <p className="text-sm text-[#4a4260]">Quote ID</p>
              <input
                value={quoteId}
                onChange={(e) => setQuoteId(e.target.value)}
                placeholder="Enter the Quote ID"
                className="h-9 w-full rounded-md border border-[#f0d8ff] bg-white px-3 outline-none"
              />
            </div>

            {/* Component Type */}
            <div className="space-y-2">
              <p className="text-sm text-[#4a4260]">Component Type</p>
              <select
                value={componentType}
                onChange={(e) => setComponentType(e.target.value as any)}
                className="h-9 w-full rounded-md border border-[#f0d8ff] bg-white px-3 outline-none"
              >
                <option value="vehicle">Vehicle</option>
                <option value="agent">Agent</option>
                <option value="guide">Guide</option>
                <option value="hotspot">Hotspot</option>
                <option value="activity">Activity</option>
                <option value="hotel">Hotel</option>
                <option value="all">All</option>
              </select>
            </div>

            {/* From Date */}
            <div className="space-y-2">
              <p className="text-sm text-[#4a4260]">From Date</p>
              <input
                type="date"
                value={fromDate}
                onChange={(e) => setFromDate(e.target.value)}
                className="h-9 w-full rounded-md border border-[#f0d8ff] bg-white px-3 outline-none"
              />
            </div>

            {/* To Date */}
            <div className="space-y-2">
              <p className="text-sm text-[#4a4260]">To Date</p>
              <input
                type="date"
                value={toDate}
                onChange={(e) => setToDate(e.target.value)}
                className="h-9 w-full rounded-md border border-[#f0d8ff] bg-white px-3 outline-none"
              />
            </div>

            {/* RIGHT-SIDE field changes per component */}
            {renderRightFieldRow1()}
          </div>

          {/* ROW 2 — ONLY WHEN VEHICLE */}
          {componentType === "vehicle" && (
            <div className="grid grid-cols-1 md:grid-cols-5 gap-4 items-end mt-4">
              {/* Branch */}
              <div className="space-y-2 md:col-span-1">
                <p className="text-sm text-[#4a4260]">Branch</p>
                <select
                  value={branch}
                  onChange={(e) => setBranch(e.target.value)}
                  className="h-9 w-full rounded-md border border-[#f0d8ff] bg-white px-3 outline-none"
                >
                  {VEHICLE_BRANCHES.map((b) => (
                    <option key={b} value={b}>
                      {b}
                    </option>
                  ))}
                </select>
              </div>

              {/* Vehicle */}
              <div className="space-y-2 md:col-span-1">
                <p className="text-sm text-[#4a4260]">Vehicle</p>
                <select
                  value={vehicle}
                  onChange={(e) => setVehicle(e.target.value)}
                  className="h-9 w-full rounded-md border border-[#f0d8ff] bg-white px-3 outline-none"
                >
                  {VEHICLE_NAMES.map((v) => (
                    <option key={v} value={v}>
                      {v}
                    </option>
                  ))}
                </select>
              </div>

              {/* spacer */}
              <div className="hidden md:block md:col-span-2" />

              {/* Clear btn right */}
              <div className="flex md:justify-end">
                <button
                  onClick={handleClear}
                  className="h-9 px-6 rounded-md bg-[#f057b8] hover:bg-[#df43a6] text-white text-sm font-medium"
                >
                  Clear
                </button>
              </div>
            </div>
          )}

          {/* NON-vehicle clear button (1 row) */}
          {componentType !== "vehicle" && (
            <div className="flex justify-end mt-4">
              <button
                onClick={handleClear}
                className="h-9 px-6 rounded-md bg-[#f057b8] hover:bg-[#df43a6] text-white text-sm font-medium"
              >
                Clear
              </button>
            </div>
          )}
        </div>
      </div>

      {/* SUMMARY CARDS */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-5">
        <div className="bg-white rounded-md shadow-sm py-4 px-5">
          <p className="text-sm text-[#8a7da5] mb-1">Total Billed</p>
          <p className="text-xl font-semibold text-[#3d3551]">{formatINR(totals.billed)}</p>
        </div>
        <div className="bg-white rounded-md shadow-sm py-4 px-5">
          <p className="text-sm text-[#8a7da5] mb-1">Total Received</p>
          <p className="text-xl font-semibold text-[#3d3551]">{formatINR(totals.received)}</p>
        </div>
        <div className="bg-white rounded-md shadow-sm py-4 px-5">
          <p className="text-sm text-[#8a7da5] mb-1">Total Receivable</p>
          <p className="text-xl font-semibold text-[#3d3551]">{formatINR(totals.receivable)}</p>
        </div>
        <div className="bg-white rounded-md shadow-sm py-4 px-5">
          <p className="text-sm text-[#8a7da5] mb-1">Total Paid</p>
          <p className="text-xl font-semibold text-[#3d3551]">{formatINR(totals.paid)}</p>
        </div>
        <div className="bg-white rounded-md shadow-sm py-4 px-5">
          <p className="text-sm text-[#8a7da5] mb-1">Total Balance</p>
          <p className="text-xl font-semibold text-[#10a037]">{formatINR(totals.balance)}</p>
        </div>
      </div>

      {/* LIST */}
      <div className="bg-white/70 rounded-xl border border-[#f6dfff]">
        <div className="flex items-center justify-between px-6 pt-5 pb-3">
          <p className="text-sm font-semibold text-[#4a4260]">List of Agent</p>
          <button className="h-9 px-4 gap-2 rounded-md bg-[#e5fff1] border border-[#b7f7d9] text-[#0f9c34] text-sm flex items-center">
            <Download className="h-4 w-4" />
            Export
          </button>
        </div>

        <div ref={listRef} className="max-h-[460px] overflow-y-auto border-t border-[#f3e0ff]">
          <table className="min-w-full text-sm">
            <thead className="bg-[#fbf2ff] sticky top-0 z-10">
              <tr>
                <th className="text-left px-6 py-3 text-xs text-[#4a4260]">BOOKING ID</th>
                <th className="text-left px-3 py-3 text-xs text-[#4a4260]">AGENT NAME</th>
                <th className="text-right px-3 py-3 text-xs text-[#4a4260]">TOTAL BILLED</th>
                <th className="text-right px-3 py-3 text-xs text-[#4a4260]">TOTAL RECEIVED</th>
                <th className="text-right px-3 py-3 text-xs text-[#4a4260]">TOTAL RECEIVABLE</th>
                <th className="text-right px-3 py-3 text-xs text-[#4a4260]">TOTAL PAID</th>
                <th className="text-right px-3 py-3 text-xs text-[#4a4260]">TOTAL BALANCE</th>
                <th className="text-left px-3 py-3 text-xs text-[#4a4260]">GUEST</th>
                <th className="text-left px-3 py-3 text-xs text-[#4a4260]">ARRIVAL</th>
                <th className="text-left px-3 py-3 text-xs text-[#4a4260]">START DATE</th>
                <th className="text-left px-3 py-3 text-xs text-[#4a4260]">END DATE</th>
              </tr>
            </thead>
            <tbody>
              {filteredRows.slice(0, visibleCount).map((row) => (
                <tr key={row.id} className="hover:bg-[#fff7ff]">
                  <td className="px-6 py-2 text-[#7032c8] font-medium">{row.bookingId}</td>
                  <td className="px-3 py-2 text-[#4a4260]">{row.agentName}</td>
                  <td className="px-3 py-2 text-right text-[#4a4260]">{formatINR(row.totalBilled)}</td>
                  <td className="px-3 py-2 text-right text-[#4a4260]">{formatINR(row.totalReceived)}</td>
                  <td className="px-3 py-2 text-right text-[#4a4260]">{formatINR(row.totalReceivable)}</td>
                  <td className="px-3 py-2 text-right text-[#4a4260]">{formatINR(row.totalPaid)}</td>
                  <td className="px-3 py-2 text-right text-[#4a4260]">{formatINR(row.totalBalance)}</td>
                  <td className="px-3 py-2 text-[#4a4260]">{row.guest}</td>
                  <td className="px-3 py-2 text-[#4a4260]">{row.arrival}</td>
                  <td className="px-3 py-2 text-[#4a4260]">{row.startDate}</td>
                  <td className="px-3 py-2 text-[#4a4260]">{row.endDate}</td>
                </tr>
              ))}

              {filteredRows.length === 0 && (
                <tr>
                  <td colSpan={11} className="text-center py-16 text-[#f4008f] text-sm">
                    No data Found
                  </td>
                </tr>
              )}

              {visibleCount < filteredRows.length && filteredRows.length > 0 && (
                <tr>
                  <td colSpan={11} className="text-center py-4 text-xs">
                    Loading more…
                  </td>
                </tr>
              )}

              {visibleCount >= filteredRows.length && filteredRows.length > 0 && (
                <tr>
                  <td colSpan={11} className="text-center py-4 text-xs">
                    All rows loaded
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        <div className="py-4 text-center text-xs text-[#a593c7]">DVI Holidays @ 2025</div>
      </div>
    </div>
  );
};

export default AccountsLedger;

import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  RadioGroup,
  RadioGroupItem,
} from "@/components/ui/radio-group";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Trash2 } from "lucide-react";

export const CreateItinerary = () => {
  const [itineraryPreference, setItineraryPreference] = useState("both");
  const [routeDetails, setRouteDetails] = useState([
    {
      day: 1,
      date: "12/12/2024",
      source: "",
      next: "",
      via: "",
      directVisit: "",
    },
  ]);
  const [rooms, setRooms] = useState([
    { id: 1, roomType: "", roomCount: 1, adults: 2, children: 0, infants: 0 },
  ]);
  const [vehicles, setVehicles] = useState([{ id: 1, type: "", count: 1 }]);

  const addDay = () => {
    setRouteDetails((prev) => [
      ...prev,
      {
        day: prev.length + 1,
        date: "",
        source: "",
        next: "",
        via: "",
        directVisit: "",
      },
    ]);
  };

  const addRoom = () => {
    setRooms((prev) => [
      ...prev,
      {
        id: prev.length + 1,
        roomType: "",
        roomCount: 1,
        adults: 2,
        children: 0,
        infants: 0,
      },
    ]);
  };

  const removeRoom = (id: number) => {
    setRooms((prev) => prev.filter((r) => r.id !== id));
  };

  const addVehicle = () => {
    setVehicles((prev) => [...prev, { id: prev.length + 1, type: "", count: 1 }]);
  };

  const removeVehicle = (id: number) => {
    setVehicles((prev) => prev.filter((v) => v.id !== id));
  };

  return (
    <div className="w-full max-w-full space-y-5 bg-[#f6edf8] min-h-screen p-4 md:p-6">
      {/* top heading like PHP */}
      <div className="flex items-center justify-between">
        <h1 className="text-lg md:text-xl font-semibold text-[#4a4260]">
          Itinerary Plan
        </h1>
      </div>

      {/* MAIN BIG CARD */}
      <Card className="border border-[#e6d4f2] shadow-none rounded-lg bg-white">
        <CardContent className="pt-4 space-y-4">
          {/* Itinerary Preference row */}
          <div className="bg-[#fef8ff] border border-[#e9d4ff] rounded-md p-3">
            <Label className="mb-2 block text-sm text-[#4a4260]">
              Itinerary Preference *
            </Label>
            <RadioGroup
              value={itineraryPreference}
              onValueChange={setItineraryPreference}
              className="flex flex-wrap gap-4"
            >
              <div className="flex items-center gap-2">
                <RadioGroupItem value="vehicle" id="vehicle" />
                <Label htmlFor="vehicle" className="text-sm">
                  Vehicle
                </Label>
              </div>
              <div className="flex items-center gap-2">
                <RadioGroupItem value="hotel" id="hotel" />
                <Label htmlFor="hotel" className="text-sm">
                  Hotel
                </Label>
              </div>
              <div className="flex items-center gap-2">
                <RadioGroupItem value="both" id="both" />
                <Label htmlFor="both" className="text-sm">
                  Both Hotel and Vehicle
                </Label>
              </div>
            </RadioGroup>
          </div>

          {/* form fields in rows like screenshot */}
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
            {/* Agent */}
            <div className="space-y-1.5">
              <Label className="text-sm">Agent *</Label>
              <Select>
                <SelectTrigger className="h-9 rounded-md border-[#e5d7f6]">
                  <SelectValue placeholder="Select Agent" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="agent1">Agent 1</SelectItem>
                  <SelectItem value="agent2">Agent 2</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Arrival */}
            <div className="space-y-1.5">
              <Label className="text-sm">Arrival *</Label>
              <Select>
                <SelectTrigger className="h-9 rounded-md border-[#e5d7f6]">
                  <SelectValue placeholder="Choose Location" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="loc1">Location 1</SelectItem>
                  <SelectItem value="loc2">Location 2</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Departure */}
            <div className="space-y-1.5">
              <Label className="text-sm">Departure *</Label>
              <Select>
                <SelectTrigger className="h-9 rounded-md border-[#e5d7f6]">
                  <SelectValue placeholder="Choose Location" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="loc1">Location 1</SelectItem>
                  <SelectItem value="loc2">Location 2</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Trip Start Date */}
            <div className="space-y-1.5">
              <Label className="text-sm">Trip Start Date *</Label>
              <Input
                placeholder="DD/MM/YYYY"
                className="h-9 rounded-md border-[#e5d7f6]"
              />
            </div>

            {/* Start Time */}
            <div className="space-y-1.5">
              <Label className="text-sm">Start Time *</Label>
              <Input
                placeholder="12:00 PM"
                className="h-9 rounded-md border-[#e5d7f6]"
              />
            </div>

            {/* Trip End Date */}
            <div className="space-y-1.5">
              <Label className="text-sm">Trip End Date *</Label>
              <Input
                placeholder="DD/MM/YYYY"
                className="h-9 rounded-md border-[#e5d7f6]"
              />
            </div>

            {/* End Time */}
            <div className="space-y-1.5">
              <Label className="text-sm">End Time *</Label>
              <Input
                placeholder="12:00 PM"
                className="h-9 rounded-md border-[#e5d7f6]"
              />
            </div>

            {/* Arrival Type */}
            <div className="space-y-1.5">
              <Label className="text-sm">Arrival Type</Label>
              <Select>
                <SelectTrigger className="h-9 rounded-md border-[#e5d7f6]">
                  <SelectValue placeholder="By Flight" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="flight">By Flight</SelectItem>
                  <SelectItem value="train">By Train</SelectItem>
                  <SelectItem value="road">By Road</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Departure Type */}
            <div className="space-y-1.5">
              <Label className="text-sm">Departure Type</Label>
              <Select>
                <SelectTrigger className="h-9 rounded-md border-[#e5d7f6]">
                  <SelectValue placeholder="By Flight" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="flight">By Flight</SelectItem>
                  <SelectItem value="train">By Train</SelectItem>
                  <SelectItem value="road">By Road</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Itinerary Type */}
            <div className="space-y-1.5">
              <Label className="text-sm">Itinerary Type *</Label>
              <Select>
                <SelectTrigger className="h-9 rounded-md border-[#e5d7f6]">
                  <SelectValue placeholder="Customize" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="customize">Customize</SelectItem>
                  <SelectItem value="standard">Standard</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Number of Days */}
            <div className="space-y-1.5">
              <Label className="text-sm">Number of Days</Label>
              <Input
                defaultValue={1}
                type="number"
                className="h-9 rounded-md border-[#e5d7f6]"
              />
            </div>

            {/* Budget */}
            <div className="space-y-1.5">
              <Label className="text-sm">Budget *</Label>
              <Input
                defaultValue={15000}
                type="number"
                className="h-9 rounded-md border-[#e5d7f6]"
              />
            </div>

            {/* Entry Ticket Required */}
            <div className="space-y-1.5">
              <Label className="text-sm">Entry Ticket Required?</Label>
              <Select>
                <SelectTrigger className="h-9 rounded-md border-[#e5d7f6]">
                  <SelectValue placeholder="No" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="yes">Yes</SelectItem>
                  <SelectItem value="no">No</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Guide for whole itinerary */}
            <div className="space-y-1.5">
              <Label className="text-sm">Guide for Whole Itinerary *</Label>
              <Select>
                <SelectTrigger className="h-9 rounded-md border-[#e5d7f6]">
                  <SelectValue placeholder="No" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="yes">Yes</SelectItem>
                  <SelectItem value="no">No</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Nationality */}
            <div className="space-y-1.5">
              <Label className="text-sm">Nationality *</Label>
              <Select>
                <SelectTrigger className="h-9 rounded-md border-[#e5d7f6]">
                  <SelectValue placeholder="India" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="india">India</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Pick up date & time */}
            <div className="space-y-1.5">
              <Label className="text-sm">Pick Up Date & Time *</Label>
              <Input
                placeholder="DD/MM/YYYY HH:MM"
                className="h-9 rounded-md border-[#e5d7f6]"
              />
            </div>

            {/* Special Instructions (full row) */}
            <div className="space-y-1.5 md:col-span-2 xl:col-span-3">
              <Label className="text-sm">Special Instructions</Label>
              <Textarea
                rows={2}
                placeholder="Enter the Special Instruction"
                className="rounded-md border-[#e5d7f6]"
              />
            </div>

            {/* No. of Adults */}
            <div className="space-y-1.5">
              <Label className="text-sm">No. of Adults *</Label>
              <Input
                defaultValue={2}
                type="number"
                className="h-9 rounded-md border-[#e5d7f6]"
              />
            </div>

            {/* No. of Children */}
            <div className="space-y-1.5">
              <Label className="text-sm">No. of Children *</Label>
              <Input
                defaultValue={0}
                type="number"
                className="h-9 rounded-md border-[#e5d7f6]"
              />
            </div>

            {/* No. of Infants */}
            <div className="space-y-1.5">
              <Label className="text-sm">No. of Infants *</Label>
              <Input
                defaultValue={0}
                type="number"
                className="h-9 rounded-md border-[#e5d7f6]"
              />
            </div>
          </div>

          {/* ROOMS box – now BELOW entry ticket etc., INSIDE same card */}
          {(itineraryPreference === "hotel" ||
            itineraryPreference === "both") && (
            <div className="border border-dashed border-[#d19de0] rounded-lg bg-[#fff9ff] p-3 mt-1">
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm font-medium text-[#4a4260]">Rooms</p>
              </div>

              {rooms.map((room, idx) => (
                <div
                  key={room.id}
                  className={`${
                    idx > 0 ? "mt-3 pt-3 border-t border-[#ecd6ff]" : ""
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-xs font-semibold text-[#4a4260]">
                      #Room {idx + 1}
                    </p>
                    {rooms.length > 1 && (
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => removeRoom(room.id)}
                        className="h-7 w-7 text-[#e63963]"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                    <div className="space-y-1.5">
                      <Label className="text-xs">Adult (Age Above 11)</Label>
                      <Input
                        defaultValue={room.adults}
                        type="number"
                        className="h-8 rounded-md border-[#e5d7f6]"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <Label className="text-xs">Child (Age 5 to 10)</Label>
                      <Input
                        defaultValue={room.children}
                        type="number"
                        className="h-8 rounded-md border-[#e5d7f6]"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <Label className="text-xs">Infant (Below 5)</Label>
                      <Input
                        defaultValue={room.infants}
                        type="number"
                        className="h-8 rounded-md border-[#e5d7f6]"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <Label className="text-xs">Room Count</Label>
                      <Input
                        defaultValue={room.roomCount}
                        type="number"
                        className="h-8 rounded-md border-[#e5d7f6]"
                      />
                    </div>
                  </div>
                </div>
              ))}

              <div className="mt-3">
                <Button
                  type="button"
                  onClick={addRoom}
                  className="h-8 px-3 bg-white border border-[#d19de0] text-[#d19de0] hover:bg-[#f5e1ff]"
                >
                  + Add Rooms
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* ROUTE DETAILS */}
      <Card className="border border-[#e6d4f2] shadow-none rounded-lg bg-white">
        <CardHeader className="pb-2">
          <CardTitle className="text-base font-semibold text-[#4a4260]">
            Route Details
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="overflow-x-auto -mx-2">
            <div className="inline-block min-w-full align-middle px-2">
              <Table>
                <TableHeader>
                  <TableRow className="bg-[#faf1ff]">
                    <TableHead className="whitespace-nowrap text-xs text-[#4a4260]">
                      DAY
                    </TableHead>
                    <TableHead className="whitespace-nowrap text-xs text-[#4a4260]">
                      DATE
                    </TableHead>
                    <TableHead className="whitespace-nowrap text-xs text-[#4a4260]">
                      SOURCE DESTINATION
                    </TableHead>
                    <TableHead className="whitespace-nowrap text-xs text-[#4a4260]">
                      NEXT DESTINATION
                    </TableHead>
                    <TableHead className="whitespace-nowrap text-xs text-[#4a4260]">
                      VIA ROUTE
                    </TableHead>
                    <TableHead className="whitespace-nowrap text-xs text-[#4a4260]">
                      DIRECT DESTINATION VISIT
                    </TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {routeDetails.map((row, index) => (
                    <TableRow key={index}>
                      <TableCell className="text-sm">{row.day}</TableCell>
                      <TableCell>
                        <Input
                          defaultValue={row.date}
                          className="h-8 min-w-[115px] rounded-md border-[#e5d7f6]"
                        />
                      </TableCell>
                      <TableCell>
                        <Input
                          placeholder="Source Location"
                          className="h-8 min-w-[160px] rounded-md border-[#e5d7f6]"
                        />
                      </TableCell>
                      <TableCell>
                        <Select>
                          <SelectTrigger className="h-8 min-w-[160px] rounded-md border-[#e5d7f6]">
                            <SelectValue placeholder="Next Destination" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="dest1">Destination 1</SelectItem>
                            <SelectItem value="dest2">Destination 2</SelectItem>
                          </SelectContent>
                        </Select>
                      </TableCell>
                      <TableCell>
                        <Button
                          variant="outline"
                          size="icon"
                          className="h-8 w-8 border-[#e5d7f6]"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </TableCell>
                      <TableCell>
                        <Input className="h-8 min-w-[150px] rounded-md border-[#e5d7f6]" />
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </div>
          <Button
            onClick={addDay}
            className="mt-4 bg-[#f054b5] hover:bg-[#e249a9]"
          >
            + Add Day
          </Button>
        </CardContent>
      </Card>

      {/* VEHICLE BLOCK (bottom) */}
      {(itineraryPreference === "vehicle" ||
        itineraryPreference === "both") && (
        <Card className="border border-[#e6d4f2] shadow-none rounded-lg bg-white">
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-semibold text-[#4a4260]">
              Vehicle
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {vehicles.map((vehicle, idx) => (
              <div
                key={vehicle.id}
                className="border border-[#f1d8ff] rounded-md p-3"
              >
                <div className="flex items-center justify-between mb-3">
                  <p className="text-sm font-medium text-[#4a4260]">
                    Vehicle #{idx + 1}
                  </p>
                  {vehicles.length > 1 && (
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => removeVehicle(vehicle.id)}
                      className="h-7 w-7 text-[#e63963]"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  )}
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <Label className="text-sm">Vehicle Type *</Label>
                    <Select>
                      <SelectTrigger className="h-9 rounded-md border-[#e5d7f6]">
                        <SelectValue placeholder="No vehicle types found" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="type1">Type 1</SelectItem>
                        <SelectItem value="type2">Type 2</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-sm">Vehicle Count *</Label>
                    <Input
                      defaultValue={vehicle.count}
                      type="number"
                      className="h-9 rounded-md border-[#e5d7f6]"
                    />
                  </div>
                </div>
              </div>
            ))}
            <Button
              onClick={addVehicle}
              className="bg-[#f054b5] hover:bg-[#e249a9]"
            >
              + Add Vehicle
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Save Button same bottom right */}
      <div className="flex justify-end">
        <Button className="bg-[#f054b5] hover:bg-[#e249a9] px-10">
          Save &amp; Continue
        </Button>
      </div>
    </div>
  );
};

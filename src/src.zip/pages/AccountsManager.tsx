import React, { useEffect, useMemo, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Download } from "lucide-react";

type AccountRow = {
  id: number;
  quoteId: string;
  hotelName: string;
  amount: number;
  payout: number;
  payable: number;
  status: "all" | "paid" | "due";
};

const formatINR = (v: number) =>
  new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    minimumFractionDigits: 2,
  }).format(v);

// create 200 mock rows
const makeMock = (): AccountRow[] => {
  const hotels = [
    "COUNTRY CLUB BEACH RESORT",
    "DVI HOLIDAYS PREMIUM",
    "LE MERIDIEN KOCHI",
    "GINGER CHENNAI",
    "THE PARK HYDERABAD",
  ];
  const rows: AccountRow[] = [];
  for (let i = 1; i <= 200; i++) {
    const hotel = hotels[i % hotels.length];
    const amt = 3500 + (i % 7) * 1250;
    const isPaid = i % 4 === 0;
    const payout = isPaid ? amt : 0;
    const payable = isPaid ? 0 : amt;
    rows.push({
      id: i,
      quoteId: `DVI0${520256 + i}`,
      hotelName: hotel,
      amount: amt,
      payout,
      payable,
      status: isPaid ? "paid" : "due",
    });
  }
  return rows;
};

const MOCK_ROWS = makeMock();

export const AccountsManager: React.FC = () => {
  const [activeTab, setActiveTab] = useState<"all" | "paid" | "due">("all");
  const [quoteIdFilter, setQuoteIdFilter] = useState("");
  const [componentType, setComponentType] = useState("all");
  const [fromDate, setFromDate] = useState("03/10/2025");
  const [toDate, setToDate] = useState("02/11/2025");
  const [agent, setAgent] = useState("");
  const [search, setSearch] = useState("");
  const [visibleCount, setVisibleCount] = useState(20);

  const scrollRef = useRef<HTMLDivElement | null>(null);

  const filteredRows = useMemo(() => {
    return MOCK_ROWS.filter((row) => {
      if (activeTab === "paid" && row.status !== "paid") return false;
      if (activeTab === "due" && row.status !== "due") return false;

      if (quoteIdFilter && !row.quoteId.includes(quoteIdFilter)) return false;

      if (search) {
        const s = search.toLowerCase();
        if (
          !row.quoteId.toLowerCase().includes(s) &&
          !row.hotelName.toLowerCase().includes(s)
        ) {
          return false;
        }
      }

      // (componentType, agent, date filters can be wired later)
      return true;
    });
  }, [activeTab, quoteIdFilter, search]);

  // TOP summary – full filtered totals
  const totalBilled = filteredRows.reduce((s, r) => s + r.amount, 0);
  const totalReceived = filteredRows
    .filter((r) => r.status === "paid")
    .reduce((s, r) => s + r.payout, 0);
  const totalReceivable = filteredRows
    .filter((r) => r.status === "due")
    .reduce((s, r) => s + r.payable, 0);
  const totalPayout = filteredRows.reduce((s, r) => s + r.payout, 0);
  const totalPayable = filteredRows.reduce((s, r) => s + r.payable, 0);
  const inHandAmount = totalReceived;
  const totalProfit = totalReceived - totalPayable;

  // BOTTOM / RUNNING totals – only for visible rows
  const visibleRows = filteredRows.slice(0, visibleCount);
  const visibleAmount = visibleRows.reduce((s, r) => s + r.amount, 0);
  const visiblePayout = visibleRows.reduce((s, r) => s + r.payout, 0);
  const visiblePayable = visibleRows.reduce((s, r) => s + r.payable, 0);
  const visibleProfit = visiblePayout - visiblePayable;
  const isAllLoaded = visibleCount >= filteredRows.length;

  // infinite scroll
  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;

    const handler = () => {
      if (el.scrollTop + el.clientHeight >= el.scrollHeight - 200) {
        setVisibleCount((prev) =>
          Math.min(prev + 20, filteredRows.length || prev)
        );
      }
    };
    el.addEventListener("scroll", handler);
    return () => el.removeEventListener("scroll", handler);
  }, [filteredRows.length]);

  // reset count when filters / tab change
  useEffect(() => {
    setVisibleCount(20);
  }, [filteredRows.length, activeTab]);

  const clearFilters = () => {
    setQuoteIdFilter("");
    setComponentType("all");
    setFromDate("");
    setToDate("");
    setAgent("");
  };

  return (
    <div className="w-full max-w-full bg-[#fbeef8] min-h-screen p-4 md:p-6">
      <h1 className="text-lg md:text-xl font-semibold text-[#4a4260] mb-4">
        Payout List
      </h1>

      {/* TABS */}
      <div className="flex gap-3 mb-4">
        <button
          onClick={() => setActiveTab("all")}
          className={`px-10 py-2 rounded-full border ${
            activeTab === "all"
              ? "bg-white text-[#4a4260] shadow-sm"
              : "bg-transparent border-transparent text-[#6a6181]"
          }`}
        >
          All
        </button>
        <button
          onClick={() => setActiveTab("paid")}
          className={`px-10 py-2 rounded-full border ${
            activeTab === "paid"
              ? "bg-white text-[#4a4260] shadow-sm"
              : "bg-transparent border-transparent text-[#6a6181]"
          }`}
        >
          Paid
        </button>
        <button
          onClick={() => setActiveTab("due")}
          className={`px-10 py-2 rounded-full border ${
            activeTab === "due"
              ? "bg-white text-[#4a4260] shadow-sm"
              : "bg-transparent border-transparent text-[#6a6181]"
          }`}
        >
          Due
        </button>
      </div>

      {/* FILTER BAR */}
      <Card className="shadow-none border-none mb-4 bg-white/70">
        <CardContent className="pt-6 pb-5">
          <p className="text-sm font-semibold text-[#4a4260] mb-4">FILTER</p>
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            <div className="space-y-2">
              <Label className="text-sm">Quote ID</Label>
              <Input
                placeholder="Enter the Quote ID"
                value={quoteIdFilter}
                onChange={(e) => setQuoteIdFilter(e.target.value)}
                className="h-9"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-sm">Component Type</Label>
              <Select
                value={componentType}
                onValueChange={(v) => setComponentType(v)}
              >
                <SelectTrigger className="h-9">
                  <SelectValue placeholder="All" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All</SelectItem>
                  <SelectItem value="hotel">Hotel</SelectItem>
                  <SelectItem value="flight">Flight</SelectItem>
                  <SelectItem value="vehicle">Vehicle</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label className="text-sm">From Date</Label>
              <Input
                placeholder="DD/MM/YYYY"
                value={fromDate}
                onChange={(e) => setFromDate(e.target.value)}
                className="h-9"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-sm">To Date</Label>
              <Input
                placeholder="DD/MM/YYYY"
                value={toDate}
                onChange={(e) => setToDate(e.target.value)}
                className="h-9"
              />
            </div>
            <div className="space-y-2 flex flex-col justify-end">
              <Label className="text-sm">Agent</Label>
              <div className="flex gap-2">
                <Select value={agent} onValueChange={(v) => setAgent(v)}>
                  <SelectTrigger className="h-9">
                    <SelectValue placeholder="Select Agent" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="agent1">Agent 1</SelectItem>
                    <SelectItem value="agent2">Agent 2</SelectItem>
                  </SelectContent>
                </Select>
                <Button
                  type="button"
                  onClick={clearFilters}
                  className="bg-[#f057b8] hover:bg-[#e348aa] text-white h-9 px-4"
                >
                  Clear
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* SUMMARY CARDS */}
      <div className="grid grid-cols-1 md:grid-cols-3 xl:grid-cols-6 gap-4 mb-5">
        <div className="bg-white rounded-md shadow-sm py-4 px-5">
          <p className="text-sm text-[#8a7da5] mb-1">Total Billed</p>
          <p className="text-xl font-semibold text-[#3d3551]">
            {formatINR(totalBilled)}
          </p>
        </div>
        <div className="bg-white rounded-md shadow-sm py-4 px-5">
          <p className="text-sm text-[#8a7da5] mb-1">Total Received</p>
          <p className="text-xl font-semibold text-[#3d3551]">
            {formatINR(totalReceived)}
          </p>
        </div>
        <div className="bg-white rounded-md shadow-sm py-4 px-5">
          <p className="text-sm text-[#8a7da5] mb-1">Total Receivable</p>
          <p className="text-xl font-semibold text-[#3d3551]">
            {formatINR(totalReceivable)}
          </p>
        </div>
        <div className="bg-white rounded-md shadow-sm py-4 px-5">
          <p className="text-sm text-[#8a7da5] mb-1">Total Payout</p>
          <p className="text-xl font-semibold text-[#3d3551]">
            {formatINR(totalPayout)}
          </p>
        </div>
        <div className="bg-white rounded-md shadow-sm py-4 px-5">
          <p className="text-sm text-[#8a7da5] mb-1">Total Payable</p>
          <p className="text-xl font-semibold text-[#3d3551]">
            {formatINR(totalPayable)}
          </p>
        </div>
        <div className="bg-white rounded-md shadow-sm py-4 px-5">
          <p className="text-sm text-[#8a7da5] mb-1">Total Profit</p>
          <p className="text-xl font-semibold text-[#10a037]">
            {formatINR(totalProfit)}
          </p>
        </div>
      </div>

      {/* LIST CARD */}
      <Card className="shadow-none border-none bg-white/70">
        <CardContent className="pt-6 pb-0">
          <div className="flex flex-col md:flex-row justify-between gap-4 mb-4">
            <p className="text-sm font-semibold text-[#4a4260]">
              List of Accounts Details
            </p>
            <div className="flex gap-3">
              <Input
                placeholder="Search..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="h-9 w-48"
              />
              <Button
                variant="outline"
                className="h-9 px-4 gap-2 bg-[#e5fff1] border-[#b7f7d9] text-[#0f9c34]"
              >
                <Download className="h-4 w-4" />
                Export
              </Button>
            </div>
          </div>
        </CardContent>

        {/* SCROLL TABLE */}
        <div
          ref={scrollRef}
          className="max-h-[460px] overflow-y-auto border-t border-[#f3e0ff]"
        >
          <Table className="min-w-full">
            <TableHeader>
              <TableRow className="bg-[#fbf2ff]">
                <TableHead className="text-xs text-[#4a4260]">QUOTE ID</TableHead>
                <TableHead className="text-xs text-[#4a4260]">ACTION</TableHead>
                <TableHead className="text-xs text-[#4a4260]">
                  HOTEL NAME
                </TableHead>
                <TableHead className="text-xs text-[#4a4260] text-right">
                  AMOUNT
                </TableHead>
                <TableHead className="text-xs text-[#4a4260] text-right">
                  PAYOUT
                </TableHead>
                <TableHead className="text-xs text-[#4a4260] text-right">
                  PAYABLE
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {visibleRows.map((row) => (
                <TableRow key={row.id} className="hover:bg-[#fff7ff]">
                  <TableCell className="text-sm text-[#7b6b99]">
                    {row.quoteId}
                  </TableCell>
                  <TableCell>
                    <Button className="h-7 bg-[#f6ecff] hover:bg-[#f6ecff] text-[#7c2f9a] px-4 rounded-md text-xs font-medium">
                      Pay Now
                    </Button>
                  </TableCell>
                  <TableCell className="text-sm text-[#4a4260]">
                    {row.hotelName}
                  </TableCell>
                  <TableCell className="text-sm text-right text-[#4a4260]">
                    {formatINR(row.amount)}
                  </TableCell>
                  <TableCell className="text-sm text-right text-[#4a4260]">
                    {formatINR(row.payout)}
                  </TableCell>
                  <TableCell className="text-sm text-right text-[#4a4260]">
                    {formatINR(row.payable)}
                  </TableCell>
                </TableRow>
              ))}
              {visibleCount < filteredRows.length ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-4 text-xs">
                    Loading more…
                  </TableCell>
                </TableRow>
              ) : (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-4 text-xs">
                    All rows loaded
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>

        {/* BOTTOM RUNNING TOTAL BAR */}
        <div className="w-full overflow-x-auto border-t border-[#f3e0ff] bg-white">
          <div className="min-w-max flex gap-6 px-6 py-3 items-center text-sm">
            <div className="text-[#4a4260] whitespace-nowrap">
              Total Amount{" "}
              <span className="font-semibold">
                ({formatINR(visibleAmount)})
              </span>
            </div>
            <div className="text-[#4a4260] whitespace-nowrap">
              Total Payout{" "}
              <span className="font-semibold">
                ({formatINR(visiblePayout)})
              </span>
            </div>
            <div className="text-[#4a4260] whitespace-nowrap">
              Total Payable{" "}
              <span className="font-semibold">
                ({formatINR(visiblePayable)})
              </span>
            </div>
            <div
              className={cnProfit(isAllLoaded, visibleProfit)}
            >
              {isAllLoaded ? formatINR(visibleProfit) : formatINR(visibleProfit)}{" "}
              {isAllLoaded ? "(Final Profit)" : "(Running Profit)"}
            </div>
          </div>
        </div>

        <div className="py-4 text-center text-xs text-[#a593c7]">
          DVI Holidays @ 2025
        </div>
      </Card>
    </div>
  );
};

// small helper to match green style only at end
function cnProfit(allLoaded: boolean, value: number) {
  if (allLoaded) {
    return "text-[#10a037] font-semibold whitespace-nowrap";
  }
  // light color while loading
  return "text-[#6f97ff] font-semibold whitespace-nowrap";
}

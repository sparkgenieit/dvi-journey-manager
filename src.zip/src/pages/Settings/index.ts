// FILE: src/pages/Settings/index.ts

export { GlobalSettingsPage } from "./GlobalSettings";
export { CitiesPage } from "./cities/Citiespage";
export { GstSettingsPage } from "./GstSettings/GstSettings";
export { InbuiltAmenitiesPage } from "./InbuiltAmenities/InbuiltAmenities";
export { HotelCategoryPage } from "./HotelCategory";
